package com.example.demo.modal;

public enum PetCondition {
	Abandoned,
	Injured,
	Stray
}
